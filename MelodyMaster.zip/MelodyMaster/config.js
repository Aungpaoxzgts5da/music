module.exports = {
    token: process.env.DISCORD_TOKEN || 'your_bot_token_here',
    clientId: process.env.CLIENT_ID || 'your_client_id_here'
};
